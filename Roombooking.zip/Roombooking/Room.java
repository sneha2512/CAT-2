
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.io.Serializable;

class Room implements Serializable
{

    int daySlot[][] = new int[7][12];	

    String name;
    int capacity;

    public Room(String n , int cap) 
    {
      this.name =n;
      this.capacity = cap;

      for (int i=0; i<7; i++)
      {
        for (int j=0; j<11; j++)
          {
            this.daySlot[i][j] = 0;
            }
          }
    }

    public boolean slotAvailable(int day, int slot)
    {
      if (daySlot[day][slot] == 1)
      {
        return false;
      }
      else
      {
        return true;
      }
    }

   

    public void book(int day , int slot)
    {
      this.daySlot[day][slot] = 1;
    }
}


