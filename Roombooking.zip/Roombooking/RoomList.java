import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.io.Serializable;

class RoomList implements Serializable 
{
	public String RoomList [] = new String [100];
}
