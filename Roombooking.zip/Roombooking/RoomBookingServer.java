import java.io.*;
import java.rmi.*;
import java.rmi.server.*;

class RoomBookingServer extends UnicastRemoteObject implements RoomBookingInterface
{

  protected int day;
  protected int time;
  protected int room;
  protected String str = new String();

  public String RoomListTemp [] = new String [100];       
  public String temp = new String();
  public Room RoomArray[] = new Room[100];                 

  RoomList tempList = new RoomList();

  public RoomBookingServer ( ) throws RemoteException
  {
    super ( );
  }


  public void initRooms() throws RemoteException
  {
    String record = null;
    String tempRoom = null;
    String tempCap = null;

    int recCount = 0;
    int num;
    int capacity;

    try
    {
      

      BufferedReader b = new BufferedReader(new FileReader("Rooms.txt"));
      while((record = b.readLine()) != null)
      {
        num = (record.lastIndexOf (" ", record.length ())) + 1;
        tempRoom = record.substring (0,num -1);                

        tempCap = record.substring  (num,record.length ());
        capacity = Integer.parseInt(tempCap);                   

        RoomArray[recCount] = new Room(tempRoom, capacity);     
        recCount ++;
      }
      b.close();    

    } catch (IOException e)
      {
        System.out.println("Error!" +e.getMessage());
      }
  }

  public RoomList allRooms() throws RemoteException
  {
    try
    {
      BufferedReader in = new BufferedReader(new FileReader("rooms.txt"));  //read in the text file.
      if((str = in.readLine()) != null)
      {
        tempList.RoomList[0] = str;
        for (int i = 1; i< 100; i++)
        {
          if((str = in.readLine()) != null)
          {
            tempList.RoomList[i] = str;
          }
        }
      }
      in.close();
    }
    catch (IOException e)
    {
    }
    return tempList;
  }



  public int compareRoom(String str)
  {
    for(int i=0; i< RoomArray.length; i++)
    {
      if(RoomArray[i].name.equals (str))
      {
        return i;
      }
    }
    return -1;
  }


  public String checkRoom(String r ,int day , int startTime) throws RemoteException
  {
    int i = compareRoom(r);
    if (RoomArray[i].slotAvailable(day, startTime) == true) //calls methos available to Room Object
    {
      String s = "Room is available for booking";
      return s;
    }
    else
    {
      String s = "Sorry the room is not available for booking";
      return s;
    }
  }



  public String bookRoom(String r, int day , int startTime) throws RemoteException
  {
    int i = compareRoom(r);

    if (RoomArray[i].slotAvailable(day, startTime) == true)
    {
      RoomArray[i].book(day,startTime);
      String s = "Room has been successfully booked.";
      return s;
    }
    else
    {
      String s = "Sorry but the Room has already been booked.";
      return s;
    }
  }


  public int [][] roomTimeTable(String room) throws RemoteException
  {
    int i;
    System.out.println("TimeTable" + room);
    for ( i = 0; i< RoomArray.length; i++)
    {
      if(RoomArray[i].name.equals(room))
      {
        return RoomArray[i].daySlot;
      }
      else
      {
        System.out.println("Searching for the room");
      }
    }

    return RoomArray[i].daySlot;
  }

  public static void main (String[] args)
  {
    try
    {
      RoomBookingServer server = new RoomBookingServer ();
      String name = "rmi://localhost:9999/RoomBookingSystem";
      Naming.bind (name, server);
      System.out.println (name + " is running");
    }
    catch (Exception ex)
    {
      System.err.println (ex);
    }
  }
}